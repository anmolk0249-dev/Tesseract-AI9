import { useState } from "react";

export default function Home() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([
    { from: "bot", text: "Hi! I'm your chatbot. Ask me anything." }
  ]);
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!input.trim()) return;
    const userMsg = { from: "user", text: input };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input })
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      const botReply = data.reply || "Sorry, I didn't get a reply.";
      setMessages((m) => [...m, { from: "bot", text: botReply }]);
    } catch (e) {
      setMessages((m) => [...m, { from: "bot", text: "Error: " + e.message }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 760, margin: "40px auto", fontFamily: "Arial, Helvetica, sans-serif" }}>
      <h1 style={{ textAlign: "center" }}>🚀 My Chatbot</h1>
      <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 16, minHeight: 300 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 12 }}>
            <strong style={{ color: m.from === "bot" ? "#0b5" : "#06f" }}>
              {m.from === "bot" ? "Bot" : "You"}
            </strong>
            <div style={{ marginTop: 4, whiteSpace: "pre-wrap" }}>{m.text}</div>
          </div>
        ))}
        {loading && <div><em>Thinking...</em></div>}
      </div>

      <div style={{ display: "flex", marginTop: 12 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Type a message..."
          style={{ flex: 1, padding: "8px 10px", fontSize: 16, borderRadius: 6, border: "1px solid #ccc" }}
        />
        <button
          onClick={send}
          disabled={loading}
          style={{ marginLeft: 8, padding: "8px 16px", fontSize: 16, borderRadius: 6 }}
        >
          Send
        </button>
      </div>
    </div>
  );
}
